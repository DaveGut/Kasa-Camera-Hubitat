library (
	name: "lib_kasaCam_ptz",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Camera Pan, Tilt, and Zoom Methods",
	category: "utilities",
	documentationLink: ""
)
command "patrolMode", [[
	name: "Patrol Mode",
	constraints: ["on", "off"],
	type: "ENUM"]]
attribute "patrolMode", "string"
command "tracking", [[
	name: "Target Tracking",
	constraints: ["on", "off"],
	type: "ENUM"]]
attribute "tracking", "string"
command "panCamera", [[
	name: "Pan Direction", type: "ENUM",
	constraints: ["left", "right"]], [
	name: "Speed (1-10)", type: "NUMBER"]]
attribute "viewpoints", "NUMBER"

def panCamera(direction, speed = 5) {
	if (speed < 1 || speed > 10) { speed = 5 }
	Map cmdData = [
		"smartlife.cam.ipcamera.ptz":[
			set_move:[direction: direction, speed: speed]]]
	asyncPost(cmdData, "panTracking")
}

def tracking(onOff) {
	Map cmdData = [
		"smartlife.cam.ipcamera.ptz":[
			set_ptz_tracking_is_enable:[value: onOff],
			get_ptz_tracking_is_enable:[]]]
	asyncPost(cmdData, "tracking")
}

def patrolMode(onOff) {
	if (device.currentValue("viewpoints") >= 2) {
		Map cmdData = [
			"smartlife.cam.ipcamera.ptz":[
				set_patrol_is_enable:[value: onOff],
				get_patrol_is_enable:[]]]
		asyncPost(cmdData, "patrolMode")
	} else {
		logWarn([method: "patrolMode", error: "At least two viewpoints must be set to start patrol mode"])
	}
}

def xxxsetViewpoint(preset) {
	Map presets = state.presets
	def presetName = presets."${preset}"
	if (presetName != null) {
		preset = preset.toInteger()
		Map cmdData = [
			"smartlife.cam.ipcamera.ptz":[
				set_run_to_preset:[index: preset]]]
		asyncPost(cmdData, "setViewpoint")
		updateAttr("lastViewpoint", presetName)
	} else {
		updateAttr("lastViewpoint", " ")
		Map warnLog = [method: "setViewpoint", preset: preset,
					   presetName: presetName, error: "noSuchPreset"]
		logWarn(warnLog)
	}
}

def parsePtz(data, source) {
	Map logData = [method: "parsePtz", source: source]
	data.value.each {
		def key = it.key
		Map valueLog = [resp: it.value]
		if (it.value.err_code == 0) {
			def setting = "ERROR"
			switch(key) {
				case "get_all_preset":
					setting = it.value.preset_attr
					updateAttr("viewpoints", setting.size())
					valueLog<< [viewpoints: setting.size()]
					break
				case "set_run_to_preset": break
				case "set_patrol_is_enable": break
				case "get_patrol_is_enable":
					setting = it.value.value
					updateAttr("patrolMode", setting)
					valueLog << [patrolMode: setting, status: "OK"]
					break
				case "set_ptz_tracking_is_enable": break
				case "get_ptz_tracking_is_enable":
					setting = it.value.value
					updateAttr("tracking", setting)
					valueLog << [tracking: setting, status: "OK"]
					break
				case "set_move": break
				default:
					valueLog << [status: "unhandled"]
			}
		} else {
			valueLog << [status: "notParsed"]
		}
		logData << ["${key}": valueLog]
	}
	logDebug(logData)
}
